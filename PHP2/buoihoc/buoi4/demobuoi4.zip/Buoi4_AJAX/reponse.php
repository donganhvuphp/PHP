<?php  
	$numberA = $_POST['numberA'];
	$numberB = $_POST['numberB'];
	$result = $numberA + $numberB;
	echo $result;
?>