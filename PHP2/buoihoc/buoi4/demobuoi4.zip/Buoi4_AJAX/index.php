<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>AJAX</title>
</head>
<body>
	<h1>Đây là trang home</h1>
	<div id="show" style="color: red;">
		
	</div>
	<form action="" method="POST">
		Number A
		<input class="form-control" type="number" name="numberA" id="numberA" />
		<br><br>

		Number B
		<input class="form-control" type="number" name="numberB" id="numberB" />
		<br><br>

		<input class="form-control" type="number" readonly="" id="result" value="">
		<button class="btn btn-primary" type="submit" name="submit" id="plus-number">
			Plus
		</button>
	</form>

	<iframe width="560" height="315" src="https://www.youtube.com/embed/5nww1oDZGmA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

	<script src="js/jquery-3.5.1.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#plus-number").click(function(e){
				e.preventDefault(); // tranh load lai trang
				var numberA = $("#numberA").val();
				var numberB = $("#numberB").val();

				$.ajax({
					url : 'reponse.php',
					type : 'POST',
					dateType : 'html',
					data: { numberA : numberA, numberB : numberB },

					success : function(data){
						$("#result").val(data);
					},

					error : function(){
						console.log('error');
					},

				});

			});
		})
	</script>
</body>
</html>