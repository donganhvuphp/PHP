<?php 
	echo "Hello ".$_POST['name']. ' age = '.$_POST['age'];
?>	