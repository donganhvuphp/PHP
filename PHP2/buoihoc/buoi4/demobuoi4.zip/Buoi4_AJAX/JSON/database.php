<?php  
	$result = array(
		1  => array(
			'name' => 'TungTK',
			'phone' => '0989789789',
			'email' => 'khactung7@gmail.com'
		),

		2  => array(
			'name' => 'Nam',
			'phone' => '0989789789',
			'email' => 'nam@gmail.com'
		),

		3  => array(
			'name' => 'Minh',
			'phone' => '0989789789',
			'email' => 'minh@gmail.com'
		),
	);

	echo json_encode($result);

	/*
	foreach ($result as $value) {
	?>	
		<tr>
			<td> <?php echo $value['name']; ?> </td>
			<td> <?php echo $value['phone']; ?> </td>
			<td> <?php echo $value['email']; ?> </td>
		</tr>
	<?php
	}
	*/

?>