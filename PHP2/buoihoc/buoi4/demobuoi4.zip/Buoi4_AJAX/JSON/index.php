<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					
					<table class="table table-bordered table-hover">
						<thead>
							<tr>
								<th>Name</th>
								<th>Phone</th>
								<th>Email</th>
							</tr>
						</thead>
						<tbody class="content">
							
						</tbody>
					</table>
					<button class="btn btn-danger" id="getData">GET DATE</button>
				</div>
			</div>
		</div>

		<script src="../js/jquery-3.5.1.min.js"></script>
		<script>
			$(document).ready(function(){
				var result = '';
				$("#getData").click(function() {
					$.ajax({
						url 	 : 'database.php',
						type     : 'POST',
						dataType : 'json',

						success : function(datas){
							$.each(datas, function(key, value) {
								result += '<tr>';
								result += '<td>' + value['name'] + '<td>';
								result += '<td>' + value['phone'] + '<td>';
								result += '<td>' + value['email'] + '<td>';
								result += '</tr>';
							});
							$(".content").append(result);
						},

						error : function(){
							console.log('error');
						}
					});
				});
			})
		</script>
	</body>
</html>