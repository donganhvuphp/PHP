<h4>DANH SÁCH HỌC VIÊN IT-PLUS</h4>
<div class="table-responsive">
	<table class="table table-hover"> 
		<thead>
			<tr>
				<th>STT</th>
				<th>Name</th>
				<th>Phone</th>
				<th>Email</th>
				<th>Addres</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>A</td>
				<td>032658749</td>
				<td>abc@gmail.com</td>
				<td>Hà Nội</td>
				<td>
					<a href="#">
						<button class="btn btn-primary">Sửa</button>
					</a>
					<a href="#">
						<button class="btn btn-danger">Xóa</button>
					</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>